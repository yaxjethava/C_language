#include<stdio.h>

main(){
	
	float b,h;
	printf("Enter a value of b and h\n");
	
	scanf("%f%f",&b,&h);
	
	float height=0.5*b*h;
	
	printf("The base b and heigh h of trianglr is %f",height);
	
}