#include<stdio.h>

main(){
	
	float l;
	
	printf("Enter the length of l\n");
	scanf("%f",&l);
	
	float length=l*l;
	
	printf("The length of rectangle is %f",length); 
	
}
