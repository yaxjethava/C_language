#include<stdio.h>

main(){
	
	float base,height;
	
	printf("Enter base and height value\n");
	
	scanf("%f%f",&base,&height);
	
	float area=0.5*base*height;
	
	printf("The demensions of triangle is %.3f",area);
	
	
}