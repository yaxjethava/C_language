#include<stdio.h>

main(){
	
	float pi=3.14;
	float r;
	
	printf("Enter a radius of circle\n");
	
	scanf("%f",&r);
	
	float redius=2*pi*r;
	
	printf("The Perimeter of Circle is %f",redius);
	
	
}