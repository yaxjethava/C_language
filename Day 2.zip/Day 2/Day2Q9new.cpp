#include<stdio.h>

main(){
	
	int s;
	printf("Enter length of a side to get volume of cube/n");
	scanf("%d",&s);
	
	int volume=s*s*s;
	
	printf("The volume of the cube is %d",volume);
	
}