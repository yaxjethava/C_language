#include<stdio.h>

main(){
	
	float sq;
	
	printf("Enter a number what you want a square\n");
	
	scanf("%f",&sq);
	
	float square=sq*sq;
	
	printf("The square of the num %.2f is %.2f",sq,square); 
	
}