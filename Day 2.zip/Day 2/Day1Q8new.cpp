#include<stdio.h>

main(){
	
	float s;
	
	printf("Enter the value of side to get area of a square\n");
	scanf("%f",s);
	
	float area= s*s;
	
	printf("The area of a square is %f",area);

}