#include<stdio.h>

main(){
	
	float pi =3.14;
	 
	float r;
	
	printf("Enter a radius of r\n");
	scanf("%f",&r);
	
	float radius=pi*r*r;
	
	printf("radius is %f",radius);
}